package model;

public class Game {
    private Board board;
    private Player player;
    private int moves;

    public Game(Player player) {
        this.player = player;
        this.board = new Board(4);
        this.moves = 0;
    }

    public boolean checkMatch(Card c1, Card c2) {
        moves++;
        if (c1.getValue().equals(c2.getValue())) {
            c1.setMatched(true);
            c2.setMatched(true);
            player.incrementScore();
            return true;
        }
        return false;
    }

    public int getMoves() { 
    	return moves; }
    public Player getPlayer() { 
    	return player; }
    public Board getBoard() {
        return board;
    }
}
