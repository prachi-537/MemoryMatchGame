package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.*;

public class GameGUI extends JFrame {
    private static final long serialVersionUID = 1L;
    private Game game;
    private JButton[][] buttons;
    private Card firstCard = null;
    private int firstRow = -1, firstCol = -1;
    private int moves = 0;
    private JLabel moveLabel;

    public GameGUI() {
        game = new Game(new Player("Prachi"));
        buttons = new JButton[4][4];

        // Top panel for score + restart
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        moveLabel = new JLabel("Moves: 0");
        JButton restartButton = new JButton("Restart 🔁");
        restartButton.addActionListener(e -> restartGame());
        topPanel.add(moveLabel);
        topPanel.add(restartButton);

        // Grid for cards
        JPanel gridPanel = new JPanel(new GridLayout(4, 4, 5, 5));

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                JButton btn = new JButton("?");
                int row = i, col = j;
                btn.setFont(new Font("Arial", Font.BOLD, 20));
                btn.addActionListener(e -> handleClick(row, col));
                buttons[i][j] = btn;
                gridPanel.add(btn);
            }
        }

        setLayout(new BorderLayout());
        add(topPanel, BorderLayout.NORTH);
        add(gridPanel, BorderLayout.CENTER);

        setTitle("Memory Match Game");
        setSize(420, 470);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void handleClick(int r, int c) {
        Card clicked = game.getBoard().getCard(r, c);

        if (clicked.isMatched() || !buttons[r][c].getText().equals("?")) {
            return;
        }

        buttons[r][c].setText(clicked.getValue());

        if (firstCard == null) {
            firstCard = clicked;
            firstRow = r;
            firstCol = c;
            return;
        }

        Card secondCard = clicked;
        moves++;
        moveLabel.setText("Moves: " + moves);

        setButtonsEnabled(false);

        Timer timer = new Timer(800, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (game.checkMatch(firstCard, secondCard)) {
                    firstCard.setMatched(true);
                    secondCard.setMatched(true);
                    buttons[firstRow][firstCol].setEnabled(false);
                    buttons[r][c].setEnabled(false);

                    if (allMatched()) {
                        JOptionPane.showMessageDialog(null,
                                "🎉 You Win, " + game.getPlayer().getName() + "! 🎉\nTotal Moves: " + moves,
                                "Game Over",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    buttons[firstRow][firstCol].setText("?");
                    buttons[r][c].setText("?");
                }

                firstCard = null;
                firstRow = -1;
                firstCol = -1;

                setButtonsEnabled(true);
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    private void setButtonsEnabled(boolean enable) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (!game.getBoard().getCard(i, j).isMatched()) {
                    buttons[i][j].setEnabled(enable);
                }
            }
        }
    }

    private boolean allMatched() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (!game.getBoard().getCard(i, j).isMatched()) {
                    return false;
                }
            }
        }
        return true;
    }

    private void restartGame() {
        game = new Game(new Player("Prachi"));
        moves = 0;
        moveLabel.setText("Moves: 0");
        firstCard = null;

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                buttons[i][j].setText("?");
                buttons[i][j].setEnabled(true);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GameGUI());
    }
}
